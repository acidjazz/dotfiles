<template>
#[[$END$]]#
</template>

<script lang="ts" setup>

</script>